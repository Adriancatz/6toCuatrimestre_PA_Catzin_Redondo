<?php

require_once "conexion.php"

$sql = "SELECT * FROM alumnos WHERE 1=1";
$params = [];

if (isset($_GET['id_alumno']) && $_GET['id_alumno'] !== '') {
    $sql .= " AND id_alumno = :id_alumno";
    $params[':id_alumno'] = $_GET['id_alumno'];
}

if (isset($_GET['apellido']) && trim($_GET['apellido']) !== '') {
    $sql .= " AND apellido LIKE :apellido";
    $params[':apellido'] = '%' . trim($_GET['apellido']) . '%';
}
try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $alumnos = $stmt->fetchAll();

    http_response_code(200);
    echo json_encode([
        'status'  => 'success',
        'total'   => count($alumnos),
        'data'    => $alumnos
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Error al consultar los registros']);
}

?>