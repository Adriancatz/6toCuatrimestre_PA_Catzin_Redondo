<?php
header("Content-Type: application/json");

$fecha = date('Y-m-d H:i:s');

echo json_encode(['fecha' => $fecha]);


?>