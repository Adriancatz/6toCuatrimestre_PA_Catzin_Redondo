const API = 'api/';
let carreras = [];
let cuatrimestres = [];
let alumnoInscripcionesActual = null;

const $ = id => document.getElementById(id);

async function pedir(url, opciones = {}) {
    const respuesta = await fetch(url, opciones);
    const datos = await respuesta.json();
    if (!respuesta.ok) throw new Error(datos.mensaje || 'Ocurrió un error');
    return datos;
}

function mostrarMensaje(texto, tipo = 'exito') {
    $('mensaje').innerHTML = `<div class="${tipo}">${texto}</div>`;
    setTimeout(() => $('mensaje').innerHTML = '', 3500);
}

async function cargarCatalogos() {
    carreras = await pedir(API + 'api_carreras.php');
    cuatrimestres = await pedir(API + 'api_cuatrimestres.php');

    $('filtroCarrera').innerHTML = '<option value="">Todas las carreras</option>' + carreras.map(c => `<option value="${c.id}">${c.nombre}</option>`).join('');
    $('idCarrera').innerHTML = carreras.map(c => `<option value="${c.id}">${c.nombre}</option>`).join('');
    $('cuatrimestreActual').innerHTML = cuatrimestres.map(c => `<option value="${c.id}">${c.nombre}</option>`).join('');
    $('rapidoCuatrimestre').innerHTML = '<option value="">No cambiar cuatrimestre</option>' + cuatrimestres.map(c => `<option value="${c.id}">${c.nombre}</option>`).join('');
}

async function cargarAlumnos() {
    try {
        const parametros = new URLSearchParams();
        if ($('buscarNombre').value.trim()) parametros.set('nombre', $('buscarNombre').value.trim());
        if ($('buscarMatricula').value.trim()) parametros.set('matricula', $('buscarMatricula').value.trim());
        if ($('filtroCarrera').value) parametros.set('carrera', $('filtroCarrera').value);

        const alumnos = await pedir(API + 'api_alumnos.php?' + parametros.toString());
        $('tablaAlumnos').innerHTML = alumnos.length ? alumnos.map(a => `
            <tr>
                <td>${a.matricula}</td>
                <td>${a.nombre} ${a.apellido_paterno} ${a.apellido_materno || ''}</td>
                <td>${a.carrera}</td><td>${a.cuatrimestre}</td><td>${a.estatus}</td>
                <td><div class="botones-tabla">
                    <button onclick="editarAlumno(${a.id})">Editar</button>
                    <button class="aviso" onclick="abrirRapido(${a.id})">Estatus/Cuatri.</button>
                    <button onclick="verInscripciones(${a.id}, '${a.nombre.replaceAll("'", "\\'")}')">Materias</button>
                    <button class="peligro" onclick="eliminarAlumno(${a.id})">Eliminar</button>
                </div></td>
            </tr>`).join('') : '<tr><td colspan="6">No se encontraron alumnos.</td></tr>';
    } catch (error) { mostrarMensaje(error.message, 'error'); }
}

function abrirFormulario() {
    $('formAlumno').reset();
    $('alumnoId').value = '';
    $('tituloFormulario').textContent = 'Registrar alumno';
    $('seccionFormulario').classList.remove('oculto');
    $('seccionFormulario').scrollIntoView({behavior:'smooth'});
}

async function editarAlumno(id) {
    try {
        const a = await pedir(API + `api_alumnos.php?id=${id}`);
        $('alumnoId').value = a.id; $('matricula').value = a.matricula; $('nombre').value = a.nombre;
        $('apellidoPaterno').value = a.apellido_paterno; $('apellidoMaterno').value = a.apellido_materno || '';
        $('correo').value = a.correo; $('telefono').value = a.telefono || ''; $('fechaNacimiento').value = a.fecha_nacimiento || '';
        $('idCarrera').value = a.id_carrera; $('cuatrimestreActual').value = a.cuatrimestre_actual; $('estatus').value = a.estatus;
        $('tituloFormulario').textContent = 'Editar alumno';
        $('seccionFormulario').classList.remove('oculto');
        $('seccionFormulario').scrollIntoView({behavior:'smooth'});
    } catch(error) { mostrarMensaje(error.message, 'error'); }
}

$('formAlumno').addEventListener('submit', async e => {
    e.preventDefault();
    const id = $('alumnoId').value;
    const datos = {
        matricula:$('matricula').value.trim(), nombre:$('nombre').value.trim(), apellido_paterno:$('apellidoPaterno').value.trim(),
        apellido_materno:$('apellidoMaterno').value.trim(), correo:$('correo').value.trim(), telefono:$('telefono').value.trim(),
        fecha_nacimiento:$('fechaNacimiento').value, id_carrera:Number($('idCarrera').value),
        cuatrimestre_actual:Number($('cuatrimestreActual').value), estatus:$('estatus').value
    };
    try {
        const resultado = await pedir(API + `api_alumnos.php${id ? '?id=' + id : ''}`, {
            method: id ? 'PUT' : 'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(datos)
        });
        mostrarMensaje(resultado.mensaje); $('seccionFormulario').classList.add('oculto'); cargarAlumnos();
    } catch(error) { mostrarMensaje(error.message, 'error'); }
});

function abrirRapido(id) {
    $('rapidoId').value = id; $('rapidoEstatus').value = ''; $('rapidoCuatrimestre').value = '';
    $('seccionRapida').classList.remove('oculto'); $('seccionRapida').scrollIntoView({behavior:'smooth'});
}

$('formRapido').addEventListener('submit', async e => {
    e.preventDefault();
    const datos = {};
    if ($('rapidoEstatus').value) datos.estatus = $('rapidoEstatus').value;
    if ($('rapidoCuatrimestre').value) datos.cuatrimestre_actual = Number($('rapidoCuatrimestre').value);
    try {
        const resultado = await pedir(API + `api_alumnos.php?id=${$('rapidoId').value}`, {
            method:'PATCH', headers:{'Content-Type':'application/json'}, body:JSON.stringify(datos)
        });
        mostrarMensaje(resultado.mensaje); $('seccionRapida').classList.add('oculto'); cargarAlumnos();
    } catch(error) { mostrarMensaje(error.message, 'error'); }
});

async function eliminarAlumno(id) {
    if (!confirm('¿Seguro que quieres eliminar este alumno?')) return;
    try {
        const resultado = await pedir(API + `api_alumnos.php?id=${id}`, {method:'DELETE'});
        mostrarMensaje(resultado.mensaje); cargarAlumnos();
    } catch(error) { mostrarMensaje(error.message, 'error'); }
}

async function verInscripciones(id, nombre) {
    alumnoInscripcionesActual = id; $('inscripcionAlumnoId').value = id;
    $('tituloInscripciones').textContent = `Materias inscritas de ${nombre}`;
    $('seccionInscripciones').classList.remove('oculto');
    await cargarMateriasAlumno();
    $('seccionInscripciones').scrollIntoView({behavior:'smooth'});
}

async function cargarMateriasAlumno() {
    try {
        const inscripciones = await pedir(API + `api_inscripciones.php?alumno=${alumnoInscripcionesActual}`);
        $('tablaInscripciones').innerHTML = inscripciones.length ? inscripciones.map(i => `
            <tr><td>${i.materia}</td><td>${i.fecha_inscripcion}</td><td>${i.calificacion ?? 'Sin calificación'}</td>
            <td>${i.periodo || ''}</td><td><button class="peligro" onclick="eliminarInscripcion(${i.id})">Eliminar</button></td></tr>`).join('')
            : '<tr><td colspan="5">Este alumno no tiene materias inscritas.</td></tr>';
    } catch(error) { mostrarMensaje(error.message, 'error'); }
}

async function cargarMaterias() {
    const materias = await pedir(API + 'api_materias.php');
    $('materiaInscripcion').innerHTML = '<option value="">Selecciona una materia</option>' + materias.map(m => `<option value="${m.id}">${m.nombre} - ${m.carrera}</option>`).join('');
}

$('formInscripcion').addEventListener('submit', async e => {
    e.preventDefault();
    const datos = {id_alumno:Number($('inscripcionAlumnoId').value), id_materia:Number($('materiaInscripcion').value), periodo:$('periodo').value.trim()};
    try {
        const resultado = await pedir(API + 'api_inscripciones.php', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(datos)});
        mostrarMensaje(resultado.mensaje); $('formInscripcion').reset(); $('inscripcionAlumnoId').value = alumnoInscripcionesActual; cargarMateriasAlumno();
    } catch(error) { mostrarMensaje(error.message, 'error'); }
});

async function eliminarInscripcion(id) {
    if (!confirm('¿Eliminar esta inscripción?')) return;
    try { const r = await pedir(API + `api_inscripciones.php?id=${id}`, {method:'DELETE'}); mostrarMensaje(r.mensaje); cargarMateriasAlumno(); }
    catch(error) { mostrarMensaje(error.message, 'error'); }
}

$('btnNuevo').addEventListener('click', abrirFormulario);
$('btnCancelar').addEventListener('click', () => $('seccionFormulario').classList.add('oculto'));
$('btnCancelarRapido').addEventListener('click', () => $('seccionRapida').classList.add('oculto'));
$('btnCerrarInscripciones').addEventListener('click', () => $('seccionInscripciones').classList.add('oculto'));
$('btnBuscar').addEventListener('click', cargarAlumnos);
$('btnLimpiar').addEventListener('click', () => { $('buscarNombre').value=''; $('buscarMatricula').value=''; $('filtroCarrera').value=''; cargarAlumnos(); });

(async function iniciar(){
    try { await cargarCatalogos(); await cargarMaterias(); await cargarAlumnos(); }
    catch(error) { mostrarMensaje(error.message, 'error'); }
})();
