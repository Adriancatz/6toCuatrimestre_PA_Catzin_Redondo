<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestor de Alumnos</title>
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body>
<header>
    <h1>Gestor Alumnos</h1>
</header>

<main>
    <section class="panel">
        <h2>Buscar</h2>
        <div class="filtros">
            <input id="buscarNombre" type="text" placeholder="Buscar por nombre">
            <input id="buscarMatricula" type="text" placeholder="Buscar por matrícula">
            <select id="filtroCarrera"><option value="">Todas las carreras</option></select>
            <button id="btnBuscar">Buscar</button>
            <button id="btnLimpiar" class="secundario">Limpiar</button>
        </div>
    </section>

    <section class="panel">
        <div class="encabezado-seccion">
            <h2>Alumnos</h2>
            <button id="btnNuevo">Registrar</button>
        </div>
        <div id="mensaje"></div>
        <div class="tabla-contenedor">
            <table>
                <thead>
                    <tr>
                        <th>Matricula</th><th>Nombre</th><th>Carrera</th><th>Cuatrimestre</th><th>Estatus</th><th>Acciones</th>
                    </tr>
                </thead>
                <tbody id="tablaAlumnos"></tbody>
            </table>
        </div>
    </section>

    <section id="seccionFormulario" class="panel oculto">
        <h2 id="tituloFormulario">Registrar alumnos</h2>
        <form id="formAlumno">
            <input type="hidden" id="alumnoId">
            <div class="grid-formulario">
                <label>Matricula<input id="matricula" required></label>
                <label>Nombre<input id="nombre" required></label>
                <label>Apellido paterno<input id="apellidoPaterno" required></label>
                <label>Apellido materno<input id="apellidoMaterno"></label>
                <label>Correo<input id="correo" type="email" required></label>
                <label>Telefono<input id="telefono"></label>
                <label>Fecha de nacimiento<input id="fechaNacimiento" type="date"></label>
                <label>Licienciatura<select id="idCarrera" required></select></label>
                <label>Cuatrimestre<select id="cuatrimestreActual" required></select></label>
                <label>Estatus
                    <select id="estatus" required>
                        <option>Activo</option><option>Baja</option><option>Egresado</option>
                    </select>
                </label>
            </div>
            <div class="acciones-formulario">
                <button type="submit">Registrar</button>
                <button type="button" id="btnCancelar" class="secundario">Cancelar</button>
            </div>
        </form>
    </section>

    <section id="seccionRapida" class="panel oculto">
        <h2>Cambiar estatus o cuatrimestre</h2>
        <form id="formRapido">
            <input type="hidden" id="rapidoId">
            <div class="filtros">
                <select id="rapidoEstatus"><option value="">No cambiar estatus</option><option>Activo</option><option>Baja</option><option>Egresado</option></select>
                <select id="rapidoCuatrimestre"><option value="">No cambiar cuatrimestre</option></select>
                <button type="submit">Actualizar</button>
                <button type="button" id="btnCancelarRapido" class="secundario">Cancelar</button>
            </div>
        </form>
    </section>

    <section id="seccionInscripciones" class="panel oculto">
        <div class="encabezado-seccion">
            <h2 id="tituloInscripciones">Materias inscritas</h2>
            <button id="btnCerrarInscripciones" class="secundario">Cerrar</button>
        </div>
        <form id="formInscripcion" class="filtros">
            <input type="hidden" id="inscripcionAlumnoId">
            <select id="materiaInscripcion" required><option value="">Selecciona una materia</option></select>
            <input id="periodo" placeholder="Periodo 2026">
            <button type="submit">Inscribir materia</button>
        </form>
        <div class="tabla-contenedor">
            <table>
                <thead><tr><th>Materia</th><th>Fecha</th><th>Calificacion</th><th>Periodo</th><th>Accion</th></tr></thead>
                <tbody id="tablaInscripciones"></tbody>
            </table>
        </div>
    </section>
</main>
<script src="js/app.js"></script>
</body>
</html>
