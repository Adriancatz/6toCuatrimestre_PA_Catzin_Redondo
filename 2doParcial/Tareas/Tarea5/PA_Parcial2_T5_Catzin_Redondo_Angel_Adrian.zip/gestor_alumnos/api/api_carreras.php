<?php
require_once "ayudantes.php";
require_once "conexion.php";

if ($_SERVER["REQUEST_METHOD"] !== "GET") {
    responder(["error" => true, "mensaje" => "Método no permitido"], 405);
}

if (isset($_GET["id"])) {
    $id = (int) $_GET["id"];
    $stmt = $conexion->prepare("SELECT id, nombre FROM carreras WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $carrera = $resultado->fetch_assoc();

    if (!$carrera) {
        responder(["error" => true, "mensaje" => "Carrera no encontrada"], 404);
    }

    responder($carrera);
}

$resultado = $conexion->query("SELECT id, nombre FROM carreras ORDER BY nombre");
responder($resultado->fetch_all(MYSQLI_ASSOC));
?>
