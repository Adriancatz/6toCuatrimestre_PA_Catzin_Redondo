<?php
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit;
}

function responder($datos, $codigo = 200) {
    http_response_code($codigo);
    echo json_encode($datos, JSON_UNESCAPED_UNICODE);
    exit;
}

function leerJson() {
    $contenido = file_get_contents("php://input");
    $datos = json_decode($contenido, true);

    if ($contenido !== "" && json_last_error() !== JSON_ERROR_NONE) {
        responder(["error" => true, "mensaje" => "El JSON enviado no es válido"], 400);
    }

    return $datos ?? [];
}
?>
