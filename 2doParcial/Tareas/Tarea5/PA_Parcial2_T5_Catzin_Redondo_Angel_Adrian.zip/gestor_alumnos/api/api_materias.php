<?php
require_once "ayudantes.php";
require_once "conexion.php";

if ($_SERVER["REQUEST_METHOD"] !== "GET") {
    responder(["error" => true, "mensaje" => "Método no permitido"], 405);
}

$sql = "SELECT m.id, m.nombre, m.creditos, m.id_carrera, c.nombre AS carrera,
               m.id_cuatrimestre, cu.nombre AS cuatrimestre
        FROM materias m
        INNER JOIN carreras c ON m.id_carrera = c.id
        INNER JOIN cuatrimestres cu ON m.id_cuatrimestre = cu.id
        WHERE 1 = 1";

$tipos = "";
$valores = [];

if (!empty($_GET["nombre"])) {
    $sql .= " AND m.nombre LIKE ?";
    $tipos .= "s";
    $valores[] = "%" . $_GET["nombre"] . "%";
}

if (!empty($_GET["carrera"])) {
    $sql .= " AND m.id_carrera = ?";
    $tipos .= "i";
    $valores[] = (int) $_GET["carrera"];
}

if (!empty($_GET["cuatrimestre"])) {
    $sql .= " AND m.id_cuatrimestre = ?";
    $tipos .= "i";
    $valores[] = (int) $_GET["cuatrimestre"];
}

$sql .= " ORDER BY m.nombre";
$stmt = $conexion->prepare($sql);

if ($tipos !== "") {
    $stmt->bind_param($tipos, ...$valores);
}

$stmt->execute();
$resultado = $stmt->get_result();
responder($resultado->fetch_all(MYSQLI_ASSOC));
?>
