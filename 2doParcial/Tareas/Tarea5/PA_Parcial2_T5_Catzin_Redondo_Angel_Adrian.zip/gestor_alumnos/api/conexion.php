<?php
// Datos de conexión a MySQL.
$host = "localhost";
$usuario = "root";
$contrasena = "";
$base_datos = "gestor_alumnos";

$conexion = new mysqli($host, $usuario, $contrasena, $base_datos);

$conexion->set_charset("utf8mb4");
?>
