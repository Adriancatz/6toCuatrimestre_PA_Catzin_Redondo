<?php
require_once "ayudantes.php";
require_once "conexion.php";

$metodo = $_SERVER["REQUEST_METHOD"];

if ($metodo === "GET") {
    $sql = "SELECT a.id, a.matricula, a.nombre, a.apellido_paterno, a.apellido_materno,
                   a.correo, a.telefono, a.fecha_nacimiento, a.id_carrera,
                   c.nombre AS carrera, a.cuatrimestre_actual,
                   cu.nombre AS cuatrimestre, a.estatus
            FROM alumnos a
            INNER JOIN carreras c ON a.id_carrera = c.id
            INNER JOIN cuatrimestres cu ON a.cuatrimestre_actual = cu.id
            WHERE 1 = 1";

    $tipos = "";
    $valores = [];

    if (!empty($_GET["matricula"])) {
        $sql .= " AND a.matricula LIKE ?";
        $tipos .= "s";
        $valores[] = "%" . $_GET["matricula"] . "%";
    }

    if (!empty($_GET["nombre"])) {
        $sql .= " AND CONCAT(a.nombre, ' ', a.apellido_paterno, ' ', IFNULL(a.apellido_materno, '')) LIKE ?";
        $tipos .= "s";
        $valores[] = "%" . $_GET["nombre"] . "%";
    }

    if (!empty($_GET["carrera"])) {
        $sql .= " AND a.id_carrera = ?";
        $tipos .= "i";
        $valores[] = (int) $_GET["carrera"];
    }

    if (!empty($_GET["id"])) {
        $sql .= " AND a.id = ?";
        $tipos .= "i";
        $valores[] = (int) $_GET["id"];
    }

    $sql .= " ORDER BY a.id DESC";
    $stmt = $conexion->prepare($sql);
    if ($tipos !== "") {
        $stmt->bind_param($tipos, ...$valores);
    }
    $stmt->execute();
    $datos = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    if (!empty($_GET["id"])) {
        if (!$datos) responder(["error" => true, "mensaje" => "Alumno no encontrado"], 404);
        responder($datos[0]);
    }

    responder($datos);
}

if ($metodo === "POST") {
    $d = leerJson();
    $obligatorios = ["matricula", "nombre", "apellido_paterno", "correo", "id_carrera", "cuatrimestre_actual"];

    foreach ($obligatorios as $campo) {
        if (!isset($d[$campo]) || trim((string)$d[$campo]) === "") {
            responder(["error" => true, "mensaje" => "Falta el campo: $campo"], 400);
        }
    }

    if (!filter_var($d["correo"], FILTER_VALIDATE_EMAIL)) {
        responder(["error" => true, "mensaje" => "El correo no es válido"], 400);
    }

    $stmt = $conexion->prepare("INSERT INTO alumnos
        (matricula, nombre, apellido_paterno, apellido_materno, correo, telefono,
         fecha_nacimiento, id_carrera, cuatrimestre_actual, estatus)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    $apellidoMaterno = $d["apellido_materno"] ?? null;
    $telefono = $d["telefono"] ?? null;
    $fecha = !empty($d["fecha_nacimiento"]) ? $d["fecha_nacimiento"] : null;
    $estatus = $d["estatus"] ?? "Activo";
    $idCarrera = (int)$d["id_carrera"];
    $cuatrimestre = (int)$d["cuatrimestre_actual"];

    $stmt->bind_param("sssssssiis", $d["matricula"], $d["nombre"], $d["apellido_paterno"],
        $apellidoMaterno, $d["correo"], $telefono, $fecha, $idCarrera, $cuatrimestre, $estatus);

    try {
        $stmt->execute();
        responder(["error" => false, "mensaje" => "Alumno registrado", "id" => $conexion->insert_id], 201);
    } catch (mysqli_sql_exception $e) {
        responder(["error" => true, "mensaje" => "La matrícula o el correo ya existen"], 400);
    }
}

if ($metodo === "PUT") {
    $d = leerJson();
    $id = isset($_GET["id"]) ? (int)$_GET["id"] : 0;
    if ($id <= 0) responder(["error" => true, "mensaje" => "Debes enviar el ID"], 400);

    $obligatorios = ["matricula", "nombre", "apellido_paterno", "correo", "id_carrera", "cuatrimestre_actual", "estatus"];
    foreach ($obligatorios as $campo) {
        if (!isset($d[$campo]) || trim((string)$d[$campo]) === "") {
            responder(["error" => true, "mensaje" => "Falta el campo: $campo"], 400);
        }
    }

    $stmt = $conexion->prepare("UPDATE alumnos SET matricula=?, nombre=?, apellido_paterno=?,
        apellido_materno=?, correo=?, telefono=?, fecha_nacimiento=?, id_carrera=?,
        cuatrimestre_actual=?, estatus=? WHERE id=?");

    $apellidoMaterno = $d["apellido_materno"] ?? null;
    $telefono = $d["telefono"] ?? null;
    $fecha = !empty($d["fecha_nacimiento"]) ? $d["fecha_nacimiento"] : null;
    $idCarrera = (int)$d["id_carrera"];
    $cuatrimestre = (int)$d["cuatrimestre_actual"];

    $stmt->bind_param("sssssssiisi", $d["matricula"], $d["nombre"], $d["apellido_paterno"],
        $apellidoMaterno, $d["correo"], $telefono, $fecha, $idCarrera,
        $cuatrimestre, $d["estatus"], $id);

    try {
        $stmt->execute();
        responder(["error" => false, "mensaje" => "Alumno actualizado"]);
    } catch (mysqli_sql_exception $e) {
        responder(["error" => true, "mensaje" => "No se pudo actualizar. Revisa matrícula y correo"], 400);
    }
}

if ($metodo === "PATCH") {
    $d = leerJson();
    $id = isset($_GET["id"]) ? (int)$_GET["id"] : 0;
    if ($id <= 0) responder(["error" => true, "mensaje" => "Debes enviar el ID"], 400);

    $campos = [];
    $tipos = "";
    $valores = [];

    if (isset($d["estatus"])) {
        if (!in_array($d["estatus"], ["Activo", "Baja", "Egresado"], true)) {
            responder(["error" => true, "mensaje" => "Estatus no válido"], 400);
        }
        $campos[] = "estatus = ?";
        $tipos .= "s";
        $valores[] = $d["estatus"];
    }

    if (isset($d["cuatrimestre_actual"])) {
        $campos[] = "cuatrimestre_actual = ?";
        $tipos .= "i";
        $valores[] = (int)$d["cuatrimestre_actual"];
    }

    if (!$campos) {
        responder(["error" => true, "mensaje" => "Envía estatus o cuatrimestre_actual"], 400);
    }

    $sql = "UPDATE alumnos SET " . implode(", ", $campos) . " WHERE id = ?";
    $tipos .= "i";
    $valores[] = $id;
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param($tipos, ...$valores);
    $stmt->execute();
    responder(["error" => false, "mensaje" => "Datos actualizados"]);
}

if ($metodo === "DELETE") {
    $id = isset($_GET["id"]) ? (int)$_GET["id"] : 0;
    if ($id <= 0) responder(["error" => true, "mensaje" => "Debes enviar el ID"], 400);

    try {
        $stmt = $conexion->prepare("DELETE FROM alumnos WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        responder(["error" => false, "mensaje" => "Alumno eliminado"]);
    } catch (mysqli_sql_exception $e) {
        responder(["error" => true, "mensaje" => "Primero elimina las inscripciones"], 400);
    }
}

responder(["error" => true, "mensaje" => "Método no permitido"], 405);
?>
