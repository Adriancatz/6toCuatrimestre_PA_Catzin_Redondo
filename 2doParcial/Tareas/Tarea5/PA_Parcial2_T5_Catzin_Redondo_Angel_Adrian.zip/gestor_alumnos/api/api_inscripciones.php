<?php
require_once "ayudantes.php";
require_once "conexion.php";

$metodo = $_SERVER["REQUEST_METHOD"];

if ($metodo === "GET") {
    if (!empty($_GET["alumno"])) {
        $idAlumno = (int)$_GET["alumno"];
        $stmt = $conexion->prepare("SELECT i.id, i.id_alumno, i.id_materia, m.nombre AS materia,
            i.fecha_inscripcion, i.calificacion, i.periodo
            FROM inscripciones i
            INNER JOIN materias m ON i.id_materia = m.id
            WHERE i.id_alumno = ? ORDER BY m.nombre");
        $stmt->bind_param("i", $idAlumno);
        $stmt->execute();
        responder($stmt->get_result()->fetch_all(MYSQLI_ASSOC));
    }

    if (!empty($_GET["materia"])) {
        $idMateria = (int)$_GET["materia"];
        $stmt = $conexion->prepare("SELECT i.id, i.id_alumno, a.matricula,
            CONCAT(a.nombre, ' ', a.apellido_paterno, ' ', IFNULL(a.apellido_materno, '')) AS alumno,
            i.fecha_inscripcion, i.calificacion, i.periodo
            FROM inscripciones i
            INNER JOIN alumnos a ON i.id_alumno = a.id
            WHERE i.id_materia = ? ORDER BY alumno");
        $stmt->bind_param("i", $idMateria);
        $stmt->execute();
        responder($stmt->get_result()->fetch_all(MYSQLI_ASSOC));
    }

    responder(["error" => true, "mensaje" => "Usa ?alumno=ID o ?materia=ID"], 400);
}

if ($metodo === "POST") {
    $d = leerJson();
    if (empty($d["id_alumno"]) || empty($d["id_materia"])) {
        responder(["error" => true, "mensaje" => "Faltan alumno o materia"], 400);
    }

    $idAlumno = (int)$d["id_alumno"];
    $idMateria = (int)$d["id_materia"];
    $fecha = $d["fecha_inscripcion"] ?? date("Y-m-d");
    $calificacion = isset($d["calificacion"]) && $d["calificacion"] !== "" ? (float)$d["calificacion"] : null;
    $periodo = $d["periodo"] ?? null;

    $verificar = $conexion->prepare("SELECT id FROM inscripciones WHERE id_alumno=? AND id_materia=?");
    $verificar->bind_param("ii", $idAlumno, $idMateria);
    $verificar->execute();
    if ($verificar->get_result()->num_rows > 0) {
        responder(["error" => true, "mensaje" => "El alumno ya está inscrito en esta materia"], 400);
    }

    $stmt = $conexion->prepare("INSERT INTO inscripciones
        (id_alumno, id_materia, fecha_inscripcion, calificacion, periodo)
        VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("iisds", $idAlumno, $idMateria, $fecha, $calificacion, $periodo);
    $stmt->execute();
    responder(["error" => false, "mensaje" => "Inscripción registrada", "id" => $conexion->insert_id], 201);
}

if ($metodo === "DELETE") {
    $id = isset($_GET["id"]) ? (int)$_GET["id"] : 0;
    if ($id <= 0) responder(["error" => true, "mensaje" => "Debes enviar el ID de inscripcion"], 400);

    $stmt = $conexion->prepare("DELETE FROM inscripciones WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    responder(["error" => false, "mensaje" => "Inscripción eliminada"]);
}

responder(["error" => true, "mensaje" => "Método no permitido"], 405);
?>
