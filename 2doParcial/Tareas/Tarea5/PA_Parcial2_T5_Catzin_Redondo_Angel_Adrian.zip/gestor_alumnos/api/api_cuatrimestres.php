<?php
require_once "ayudantes.php";
require_once "conexion.php";

if ($_SERVER["REQUEST_METHOD"] !== "GET") {
    responder(["error" => true, "mensaje" => "Método no permitido"], 405);
}

$resultado = $conexion->query("SELECT id, nombre FROM cuatrimestres ORDER BY id");
responder($resultado->fetch_all(MYSQLI_ASSOC));
?>
