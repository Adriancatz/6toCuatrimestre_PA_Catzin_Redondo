<?php
require_once('../config/connection.php');

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'OPTIONS') {
    http_response_code(200);
    echo json_encode(array("mensaje" => "Preflight OK"));
    $conn->close();
    exit;
}

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $stmt = $conn->prepare("SELECT id, id_prestamo, id_libro, cantidad FROM detalle_prestamo WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $resultado = $stmt->get_result();

            if ($resultado->num_rows > 0) {
                http_response_code(200);
                echo json_encode($resultado->fetch_assoc());
            } else {
                http_response_code(404);
                echo json_encode(array("mensaje" => "Detalle de prestamo no encontrado"));
            }
            $stmt->close();
        } elseif (isset($_GET['prestamo'])) {
            $id_prestamo = intval($_GET['prestamo']);
            $stmt = $conn->prepare("SELECT id, id_prestamo, id_libro, cantidad FROM detalle_prestamo WHERE id_prestamo = ? ORDER BY id");
            $stmt->bind_param("i", $id_prestamo);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $detalles = array();

            while ($row = $resultado->fetch_assoc()) {
                $detalles[] = $row;
            }

            http_response_code(200);
            echo json_encode($detalles);
            $stmt->close();
        } elseif (isset($_GET['libro'])) {
            $id_libro = intval($_GET['libro']);
            $stmt = $conn->prepare("SELECT id, id_prestamo, id_libro, cantidad FROM detalle_prestamo WHERE id_libro = ? ORDER BY id");
            $stmt->bind_param("i", $id_libro);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $detalles = array();

            while ($row = $resultado->fetch_assoc()) {
                $detalles[] = $row;
            }

            http_response_code(200);
            echo json_encode($detalles);
            $stmt->close();
        } elseif (isset($_GET['id_libro'])) {
            $id_libro = intval($_GET['id_libro']);
            $con_libro = isset($_GET['con_libro']) && strtolower(trim($_GET['con_libro'])) === 'true';

            if ($con_libro) {
                $stmt = $conn->prepare("SELECT detalle_prestamo.id, detalle_prestamo.id_prestamo, detalle_prestamo.id_libro, detalle_prestamo.cantidad, libros.titulo, libros.isbn FROM detalle_prestamo INNER JOIN libros ON detalle_prestamo.id_libro = libros.id WHERE detalle_prestamo.id_libro = ? ORDER BY detalle_prestamo.id");
            } else {
                $stmt = $conn->prepare("SELECT id, id_prestamo, id_libro, cantidad FROM detalle_prestamo WHERE id_libro = ? ORDER BY id");
            }

            $stmt->bind_param("i", $id_libro);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $detalles = array();

            while ($row = $resultado->fetch_assoc()) {
                $detalles[] = $row;
            }

            http_response_code(200);
            echo json_encode($detalles);
            $stmt->close();
        } else {
            $stmt = $conn->prepare("SELECT id, id_prestamo, id_libro, cantidad FROM detalle_prestamo ORDER BY id");
            $stmt->execute();
            $resultado = $stmt->get_result();
            $detalles = array();

            while ($row = $resultado->fetch_assoc()) {
                $detalles[] = $row;
            }

            http_response_code(200);
            echo json_encode($detalles);
            $stmt->close();
        }
        $conn->close();
        break;

    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);

        $id_prestamo = intval($data['id_prestamo'] ?? 0);
        $id_libro = intval($data['id_libro'] ?? 0);
        $cantidad = intval($data['cantidad'] ?? 0);

        if ($id_prestamo <= 0 || $id_libro <= 0 || $cantidad <= 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "Los datos son obligatorios"));
            break;
        }

        $buscarPrestamo = $conn->prepare("SELECT id FROM prestamos WHERE id = ?");
        $buscarPrestamo->bind_param("i", $id_prestamo);
        $buscarPrestamo->execute();

        if ($buscarPrestamo->get_result()->num_rows == 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El prestamo no existe"));
            break;
        }

        $buscarLibro = $conn->prepare("SELECT id FROM libros WHERE id = ?");
        $buscarLibro->bind_param("i", $id_libro);
        $buscarLibro->execute();

        if ($buscarLibro->get_result()->num_rows == 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El libro no existe"));
            break;
        }

        $stmt = $conn->prepare("INSERT INTO detalle_prestamo (id_prestamo, id_libro, cantidad) VALUES (?, ?, ?)");
        $stmt->bind_param("iii", $id_prestamo, $id_libro, $cantidad);

        if ($stmt->execute()) {
            http_response_code(201);
            echo json_encode(array("mensaje" => "Detalle creado exitosamente"));
        } else {
            http_response_code(500);
            echo json_encode(array("mensaje" => "Error al crear el detalle: " . $stmt->error));
        }
        $stmt->close();
        break;

    case 'PUT':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $data = json_decode(file_get_contents("php://input"), true);

            $id_prestamo = intval($data['id_prestamo'] ?? 0);
            $id_libro = intval($data['id_libro'] ?? 0);
            $cantidad = intval($data['cantidad'] ?? 0);

            if ($id_prestamo <= 0 || $id_libro <= 0 || $cantidad <= 0) {
                http_response_code(400);
                echo json_encode(array("mensaje" => "Los datos son obligatorios"));
                break;
            }

            $buscar = $conn->prepare("SELECT id FROM detalle_prestamo WHERE id = ?");
            $buscar->bind_param("i", $id);
            $buscar->execute();

            if ($buscar->get_result()->num_rows == 0) {
                http_response_code(404);
                echo json_encode(array("mensaje" => "Detalle no encontrado"));
                break;
            }

            $buscarPrestamo = $conn->prepare("SELECT id FROM prestamos WHERE id = ?");
            $buscarPrestamo->bind_param("i", $id_prestamo);
            $buscarPrestamo->execute();

            if ($buscarPrestamo->get_result()->num_rows == 0) {
                http_response_code(400);
                echo json_encode(array("mensaje" => "El prestamo no existe"));
                break;
            }

            $buscarLibro = $conn->prepare("SELECT id FROM libros WHERE id = ?");
            $buscarLibro->bind_param("i", $id_libro);
            $buscarLibro->execute();

            if ($buscarLibro->get_result()->num_rows == 0) {
                http_response_code(400);
                echo json_encode(array("mensaje" => "El libro no existe"));
                break;
            }

            $stmt = $conn->prepare("UPDATE detalle_prestamo SET id_prestamo = ?, id_libro = ?, cantidad = ? WHERE id = ?");
            $stmt->bind_param("iiii", $id_prestamo, $id_libro, $cantidad, $id);

            if ($stmt->execute()) {
                http_response_code(200);
                echo json_encode(array("mensaje" => "Detalle actualizado exitosamente"));
            } else {
                http_response_code(500);
                echo json_encode(array("mensaje" => "Error al actualizar el detalle: " . $stmt->error));
            }
            $stmt->close();
        } else {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio"));
        }
        break;

    case 'PATCH':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $data = json_decode(file_get_contents("php://input"), true);
            $cantidad = intval($data['cantidad'] ?? 0);

            if ($cantidad <= 0) {
                http_response_code(400);
                echo json_encode(array("mensaje" => "La cantidad debe ser mayor a 0"));
                break;
            }

            $buscar = $conn->prepare("SELECT id FROM detalle_prestamo WHERE id = ?");
            $buscar->bind_param("i", $id);
            $buscar->execute();

            if ($buscar->get_result()->num_rows == 0) {
                http_response_code(404);
                echo json_encode(array("mensaje" => "Detalle no encontrado"));
                break;
            }

            $stmt = $conn->prepare("UPDATE detalle_prestamo SET cantidad = ? WHERE id = ?");
            $stmt->bind_param("ii", $cantidad, $id);

            if ($stmt->execute()) {
                http_response_code(200);
                echo json_encode(array("mensaje" => "Cantidad actualizada exitosamente"));
            } else {
                http_response_code(500);
                echo json_encode(array("mensaje" => "Error al actualizar la cantidad: " . $stmt->error));
            }
            $stmt->close();
        } else {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio"));
        }
        break;

    case 'DELETE':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);

            $buscar = $conn->prepare("SELECT id FROM detalle_prestamo WHERE id = ?");
            $buscar->bind_param("i", $id);
            $buscar->execute();

            if ($buscar->get_result()->num_rows == 0) {
                http_response_code(404);
                echo json_encode(array("mensaje" => "Detalle no encontrado"));
                break;
            }

            $stmt = $conn->prepare("DELETE FROM detalle_prestamo WHERE id = ?");
            $stmt->bind_param("i", $id);

            if ($stmt->execute()) {
                http_response_code(200);
                echo json_encode(array("mensaje" => "Detalle eliminado exitosamente"));
            } else {
                http_response_code(500);
                echo json_encode(array("mensaje" => "Error al eliminar el detalle: " . $stmt->error));
            }
            $stmt->close();
        } else {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio"));
        }
        break;

    default:
        http_response_code(405);
        echo json_encode(array("mensaje" => "Metodo no permitido"));
        $conn->close();
        break;
}
?>