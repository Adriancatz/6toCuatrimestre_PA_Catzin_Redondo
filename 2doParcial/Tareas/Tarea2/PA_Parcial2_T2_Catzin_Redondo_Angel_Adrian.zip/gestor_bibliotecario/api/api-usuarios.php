<?php
require_once('../config/connection.php');

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'OPTIONS') {
    http_response_code(200);
    echo json_encode(array("mensaje" => "Preflight OK"));
    $conn->close();
    exit;
}

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $stmt = $conn->prepare("SELECT id, nombre, apellido, correo, telefono, id_rol, activo, fecha_registro FROM usuarios WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $resultado = $stmt->get_result();

            if ($resultado->num_rows > 0) {
                http_response_code(200);
                echo json_encode($resultado->fetch_assoc());
            } else {
                http_response_code(404);
                echo json_encode(array("mensaje" => "Usuario no encontrado"));
            }
            $stmt->close();
        } elseif (isset($_GET['nombre'])) {
            $nombre = trim($_GET['nombre']);
            $nombre_param = "%$nombre%";
            $stmt = $conn->prepare("SELECT id, nombre, apellido, correo, telefono, id_rol, activo, fecha_registro FROM usuarios WHERE nombre LIKE ? ORDER BY id");
            $stmt->bind_param("s", $nombre_param);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $usuarios = array();

            while ($row = $resultado->fetch_assoc()) {
                $usuarios[] = $row;
            }

            http_response_code(200);
            echo json_encode($usuarios);
            $stmt->close();
        } elseif (isset($_GET['correo'])) {
            $correo = trim($_GET['correo']);
            $stmt = $conn->prepare("SELECT id, nombre, apellido, correo, telefono, id_rol, activo, fecha_registro FROM usuarios WHERE correo = ? ORDER BY id");
            $stmt->bind_param("s", $correo);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $usuarios = array();

            while ($row = $resultado->fetch_assoc()) {
                $usuarios[] = $row;
            }

            http_response_code(200);
            echo json_encode($usuarios);
            $stmt->close();
        } elseif (isset($_GET['id_rol'])) {
            $id_rol = intval($_GET['id_rol']);
            $stmt = $conn->prepare("SELECT id, nombre, apellido, correo, telefono, id_rol, activo, fecha_registro FROM usuarios WHERE id_rol = ? ORDER BY id");
            $stmt->bind_param("i", $id_rol);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $usuarios = array();

            while ($row = $resultado->fetch_assoc()) {
                $usuarios[] = $row;
            }

            http_response_code(200);
            echo json_encode($usuarios);
            $stmt->close();
        } else {
            $stmt = $conn->prepare("SELECT id, nombre, apellido, correo, telefono, id_rol, activo, fecha_registro FROM usuarios ORDER BY id");
            $stmt->execute();
            $resultado = $stmt->get_result();
            $usuarios = array();

            while ($row = $resultado->fetch_assoc()) {
                $usuarios[] = $row;
            }

            http_response_code(200);
            echo json_encode($usuarios);
            $stmt->close();
        }
        $conn->close();
        break;

    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);

        $nombre = trim($data['nombre'] ?? "");
        $apellido = trim($data['apellido'] ?? "");
        $correo = trim($data['correo'] ?? "");
        $password = trim($data['password'] ?? "");
        $telefono = trim($data['telefono'] ?? "");
        $id_rol = intval($data['id_rol'] ?? 0);
        $activo = intval($data['activo'] ?? 1);

        if ($nombre == "" || $apellido == "" || $correo == "" || $password == "" || $id_rol <= 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "Faltan campos obligatorios"));
            break;
        }

        if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "Correo no valido"));
            break;
        }

        $buscarRol = $conn->prepare("SELECT id FROM roles WHERE id = ?");
        $buscarRol->bind_param("i", $id_rol);
        $buscarRol->execute();

        if ($buscarRol->get_result()->num_rows == 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El rol no existe"));
            break;
        }

        $password = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $conn->prepare("INSERT INTO usuarios (nombre, apellido, correo, password, telefono, id_rol, activo) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssii", $nombre, $apellido, $correo, $password, $telefono, $id_rol, $activo);

        if ($stmt->execute()) {
            http_response_code(201);
            echo json_encode(array("mensaje" => "Usuario creado exitosamente"));
        } else {
            http_response_code(500);
            echo json_encode(array("mensaje" => "Error al crear el usuario: " . $stmt->error));
        }
        $stmt->close();
        break;

    case 'PUT':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $data = json_decode(file_get_contents("php://input"), true);

            $nombre = trim($data['nombre'] ?? "");
            $apellido = trim($data['apellido'] ?? "");
            $correo = trim($data['correo'] ?? "");
            $password = trim($data['password'] ?? "");
            $telefono = trim($data['telefono'] ?? "");
            $id_rol = intval($data['id_rol'] ?? 0);
            $activo = intval($data['activo'] ?? 1);

            if ($nombre == "" || $apellido == "" || $correo == "" || $password == "" || $id_rol <= 0) {
                http_response_code(400);
                echo json_encode(array("mensaje" => "Faltan campos obligatorios"));
                break;
            }

            $buscar = $conn->prepare("SELECT id FROM usuarios WHERE id = ?");
            $buscar->bind_param("i", $id);
            $buscar->execute();

            if ($buscar->get_result()->num_rows == 0) {
                http_response_code(404);
                echo json_encode(array("mensaje" => "Usuario no encontrado"));
                break;
            }

            $buscarRol = $conn->prepare("SELECT id FROM roles WHERE id = ?");
            $buscarRol->bind_param("i", $id_rol);
            $buscarRol->execute();

            if ($buscarRol->get_result()->num_rows == 0) {
                http_response_code(400);
                echo json_encode(array("mensaje" => "El rol no existe"));
                break;
            }

            $password = password_hash($password, PASSWORD_DEFAULT);

            $stmt = $conn->prepare("UPDATE usuarios SET nombre = ?, apellido = ?, correo = ?, password = ?, telefono = ?, id_rol = ?, activo = ? WHERE id = ?");
            $stmt->bind_param("sssssiii", $nombre, $apellido, $correo, $password, $telefono, $id_rol, $activo, $id);

            if ($stmt->execute()) {
                http_response_code(200);
                echo json_encode(array("mensaje" => "Usuario actualizado exitosamente"));
            } else {
                http_response_code(500);
                echo json_encode(array("mensaje" => "Error al actualizar el usuario: " . $stmt->error));
            }
            $stmt->close();
        } else {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio"));
        }
        break;

    case 'PATCH':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $data = json_decode(file_get_contents("php://input"), true);

            $buscar = $conn->prepare("SELECT * FROM usuarios WHERE id = ?");
            $buscar->bind_param("i", $id);
            $buscar->execute();
            $resultado = $buscar->get_result();

            if ($resultado->num_rows == 0) {
                http_response_code(404);
                echo json_encode(array("mensaje" => "Usuario no encontrado"));
                break;
            }

            $usuario = $resultado->fetch_assoc();

            $nombre = isset($data['nombre']) ? trim($data['nombre']) : $usuario['nombre'];
            $apellido = isset($data['apellido']) ? trim($data['apellido']) : $usuario['apellido'];
            $correo = isset($data['correo']) ? trim($data['correo']) : $usuario['correo'];
            $telefono = isset($data['telefono']) ? trim($data['telefono']) : $usuario['telefono'];
            $id_rol = isset($data['id_rol']) ? intval($data['id_rol']) : $usuario['id_rol'];
            $activo = isset($data['activo']) ? intval($data['activo']) : $usuario['activo'];
            $password = $usuario['password'];

            if (isset($data['password']) && trim($data['password']) != "") {
                $password = password_hash(trim($data['password']), PASSWORD_DEFAULT);
            }

            $stmt = $conn->prepare("UPDATE usuarios SET nombre = ?, apellido = ?, correo = ?, password = ?, telefono = ?, id_rol = ?, activo = ? WHERE id = ?");
            $stmt->bind_param("sssssiii", $nombre, $apellido, $correo, $password, $telefono, $id_rol, $activo, $id);

            if ($stmt->execute()) {
                http_response_code(200);
                echo json_encode(array("mensaje" => "Usuario actualizado exitosamente"));
            } else {
                http_response_code(500);
                echo json_encode(array("mensaje" => "Error al actualizar el usuario: " . $stmt->error));
            }
            $stmt->close();
        } else {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio"));
        }
        break;

    case 'DELETE':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);

            $buscar = $conn->prepare("SELECT id FROM usuarios WHERE id = ?");
            $buscar->bind_param("i", $id);
            $buscar->execute();

            if ($buscar->get_result()->num_rows == 0) {
                http_response_code(404);
                echo json_encode(array("mensaje" => "Usuario no encontrado"));
                break;
            }

            $stmt = $conn->prepare("DELETE FROM usuarios WHERE id = ?");
            $stmt->bind_param("i", $id);

            if ($stmt->execute()) {
                http_response_code(200);
                echo json_encode(array("mensaje" => "Usuario eliminado exitosamente"));
            } else {
                http_response_code(500);
                echo json_encode(array("mensaje" => "Error al eliminar el usuario: " . $stmt->error));
            }
            $stmt->close();
        } else {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio"));
        }
        break;

    default:
        http_response_code(405);
        echo json_encode(array("mensaje" => "Metodo no permitido"));
        $conn->close();
        break;
}
?>