<?php
    require_once "config/connection.php";

    $totales = [
        "categorias" => 0,
        "autores" => 0,
        "libros" => 0,
        "usuarios" => 0,
        "prestamos_activos" => 0,
    ];

    $stmt = $conn->prepare("SELECT COUNT(*) AS total FROM categorias");
    $stmt->execute();
    $resultado = $stmt->get_result();
    $totales["categorias"] = (int) ($resultado->fetch_assoc()["total"] ?? 0);
    $stmt->close();

    $stmt = $conn->prepare("SELECT COUNT(*) AS total FROM autores");
    $stmt->execute();
    $resultado = $stmt->get_result();
    $totales["autores"] = (int) ($resultado->fetch_assoc()["total"] ?? 0);
    $stmt->close();

    $stmt = $conn->prepare("SELECT COUNT(*) AS total FROM libros");
    $stmt->execute();
    $resultado = $stmt->get_result();
    $totales["libros"] = (int) ($resultado->fetch_assoc()["total"] ?? 0);
    $stmt->close();

    $stmt = $conn->prepare("SELECT COUNT(*) AS total FROM usuarios WHERE activo = 1");
    $stmt->execute();
    $resultado = $stmt->get_result();
    $totales["usuarios"] = (int) ($resultado->fetch_assoc()["total"] ?? 0);
    $stmt->close();

    $stmt = $conn->prepare("SELECT COUNT(*) AS total FROM prestamos WHERE estado = ?");
    $estadoPrestado = "prestado";
    $stmt->bind_param("s", $estadoPrestado);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $totales["prestamos_activos"] = (int) ($resultado->fetch_assoc()["total"] ?? 0);
    $stmt->close();

    $ultimosPrestamos = [];
    $stmt = $conn->prepare("SELECT prestamos.id, usuarios.nombre, usuarios.apellido, prestamos.fecha_prestamo, prestamos.fecha_devolucion, prestamos.estado FROM prestamos INNER JOIN usuarios ON prestamos.id_usuario = usuarios.id ORDER BY prestamos.id DESC LIMIT 5");
    $stmt->execute();
    $resultado = $stmt->get_result();
    while ($row = $resultado->fetch_assoc()) {
        $ultimosPrestamos[] = $row;
    }
    $stmt->close();
    $conn->close();
?>
<?php include_once "includes/header.php"; ?>

<div class="page-header">
    <h1><i class="fas fa-home"></i> Dashboard</h1>
</div>

<div class="table-container" style="padding: 24px; margin-bottom: 24px;">
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 16px;">
        <div class="card" style="padding: 18px; max-width: 100%;">
            <h2 style="font-size: 16px; margin-bottom: 10px;"><i class="fas fa-tags"></i> Categorías</h2>
            <p style="font-size: 28px; font-weight: 700; color: #1e293b;"><?= htmlspecialchars((string) $totales["categorias"]) ?></p>
        </div>
        <div class="card" style="padding: 18px; max-width: 100%;">
            <h2 style="font-size: 16px; margin-bottom: 10px;"><i class="fas fa-user"></i> Autores</h2>
            <p style="font-size: 28px; font-weight: 700; color: #1e293b;"><?= htmlspecialchars((string) $totales["autores"]) ?></p>
        </div>
        <div class="card" style="padding: 18px; max-width: 100%;">
            <h2 style="font-size: 16px; margin-bottom: 10px;"><i class="fas fa-book"></i> Libros</h2>
            <p style="font-size: 28px; font-weight: 700; color: #1e293b;"><?= htmlspecialchars((string) $totales["libros"]) ?></p>
        </div>
        <div class="card" style="padding: 18px; max-width: 100%;">
            <h2 style="font-size: 16px; margin-bottom: 10px;"><i class="fas fa-users"></i> Usuarios Activos</h2>
            <p style="font-size: 28px; font-weight: 700; color: #1e293b;"><?= htmlspecialchars((string) $totales["usuarios"]) ?></p>
        </div>
        <div class="card" style="padding: 18px; max-width: 100%;">
            <h2 style="font-size: 16px; margin-bottom: 10px;"><i class="fas fa-hand-holding-heart"></i> Préstamos Activos</h2>
            <p style="font-size: 28px; font-weight: 700; color: #1e293b;"><?= htmlspecialchars((string) $totales["prestamos_activos"]) ?></p>
        </div>
    </div>
</div>

<div class="page-header" style="margin-top: 8px;">
    <h1 style="font-size: 22px;"><i class="fas fa-clock"></i> Últimos Préstamos</h1>
</div>

<div class="table-container">
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Usuario</th>
                <th>Fecha Préstamo</th>
                <th>Fecha Devolución</th>
                <th>Estado</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($ultimosPrestamos)): ?>
                <tr>
                    <td colspan="5" class="empty-state">
                        <i class="fas fa-inbox"></i>
                        <p>No hay préstamos registrados todavía.</p>
                    </td>
                </tr>
            <?php else: ?>
                <?php foreach ($ultimosPrestamos as $prestamo): ?>
                    <tr>
                        <td><?= htmlspecialchars($prestamo["id"]) ?></td>
                        <td><?= htmlspecialchars($prestamo["nombre"] . " " . $prestamo["apellido"]) ?></td>
                        <td><?= htmlspecialchars($prestamo["fecha_prestamo"]) ?></td>
                        <td><?= htmlspecialchars($prestamo["fecha_devolucion"]) ?></td>
                        <td><?= htmlspecialchars($prestamo["estado"]) ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include_once "includes/footer.php"; ?>