<?php
    require_once "../config/connection.php";
?>
<?php include_once "../includes/header.php"; ?>

<div class="page-header">
    <h1><i class="fas fa-book-reader"></i> Préstamos</h1>
    <a href="create.php" class="btn btn-primary">
        <i class="fas fa-plus"></i> Nuevo Préstamo
    </a>
</div>

<?php if (isset($_GET["success"])): ?>
    <div class="alert alert-success">
        <i class="fas fa-check-circle"></i>
        <?= htmlspecialchars($_GET["success"]) ?>
    </div>
<?php elseif (isset($_GET["error"])): ?>
    <div class="alert alert-danger">
        <i class="fas fa-exclamation-circle"></i>
        <?= htmlspecialchars($_GET["error"]) ?>
    </div>
<?php endif; ?>

<div class="table-container">
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Usuario</th>
                <th>Fecha Préstamo</th>
                <th>Fecha Devolución</th>
                <th>Estado</th>
                <th>Libro</th>
                <th>Total</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $stmt = $conn->prepare(
                    "SELECT prestamos.id, usuarios.nombre AS nombre_usuario, usuarios.apellido AS apellido_usuario, prestamos.fecha_prestamo, prestamos.fecha_devolucion, prestamos.estado, COALESCE(GROUP_CONCAT(libros.titulo SEPARATOR ', '), '') AS libros_titulos, COALESCE(SUM(detalle_prestamo.cantidad), 0) AS total_libros FROM prestamos LEFT JOIN usuarios ON prestamos.id_usuario = usuarios.id LEFT JOIN detalle_prestamo ON prestamos.id = detalle_prestamo.id_prestamo LEFT JOIN libros ON detalle_prestamo.id_libro = libros.id GROUP BY prestamos.id, usuarios.nombre, usuarios.apellido, prestamos.fecha_prestamo, prestamos.fecha_devolucion, prestamos.estado ORDER BY prestamos.id DESC"
                );
                $stmt->execute();
                $resultado = $stmt->get_result();
                while ($row = $resultado->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row["id"]) . "</td>";
                    echo "<td>" . htmlspecialchars($row["nombre_usuario"] . " " . $row["apellido_usuario"]) . "</td>";
                    echo "<td>" . htmlspecialchars($row["fecha_prestamo"]) . "</td>";
                    echo "<td>" . htmlspecialchars($row["fecha_devolucion"]) . "</td>";
                    echo "<td>" . htmlspecialchars($row["estado"]) . "</td>";
                    echo "<td>" . htmlspecialchars($row["libros_titulos"]) . "</td>";
                    echo "<td>" . htmlspecialchars($row["total_libros"]) . "</td>";
                    echo "<td>";
                    echo "<a href='edit.php?id=" . urlencode($row["id"]) . "' class='btn btn-sm btn-warning'><i class='fas fa-edit'></i> Editar</a> ";
                    echo "<a href='delete.php?id=" . urlencode($row["id"]) . "' class='btn btn-sm btn-danger'><i class='fas fa-trash'></i> Eliminar</a>";
                    echo "</td>";
                    echo "</tr>";
                }
                $stmt->close();
                $conn->close();
            ?>
        </tbody>
    </table>
</div>

<?php include_once "../includes/footer.php"; ?>