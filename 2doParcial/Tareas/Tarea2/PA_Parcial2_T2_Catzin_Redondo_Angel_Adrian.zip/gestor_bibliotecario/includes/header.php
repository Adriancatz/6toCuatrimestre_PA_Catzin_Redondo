<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestor Bibliotecario</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <?php
        $ruta = $_SERVER['PHP_SELF'] ?? '';
        $rutaNormalizada = str_replace('\\', '/', $ruta);
        $enRaizProyecto = preg_match('#/gestor_bibliotecario/(index\.php|dashboard\.php)$#', $rutaNormalizada) === 1;
        $basePath = $enRaizProyecto ? '' : '../';
        $dashboardActivo = $enRaizProyecto || strpos($rutaNormalizada, 'dashboard.php') !== false;
    ?>
    <link rel="stylesheet" href="<?= htmlspecialchars($basePath) ?>assets/css/style.css">
</head>
<body>

<aside class="sidebar">
    <div class="sidebar-header">
        <h2><i class="fas fa-book-open"></i> Bibliotech</h2>
        <p>Sistema de Gestión</p>
    </div>
    <nav class="sidebar-nav">
        <a href="<?= htmlspecialchars($basePath) ?>index.php" <?= $dashboardActivo ? 'class="active"' : '' ?>><i class="fas fa-home"></i> Dashboard</a>
        <a href="<?= htmlspecialchars($basePath) ?>categorias/index.php" <?= strpos($rutaNormalizada, 'categorias') !== false ? 'class="active"' : '' ?>><i class="fas fa-tags"></i> Categorías</a>
        <a href="<?= htmlspecialchars($basePath) ?>autores/index.php" <?= strpos($rutaNormalizada, 'autores') !== false ? 'class="active"' : '' ?>><i class="fas fa-user"></i> Autores</a>
        <a href="<?= htmlspecialchars($basePath) ?>libros/index.php" <?= strpos($rutaNormalizada, 'libros') !== false ? 'class="active"' : '' ?>><i class="fas fa-book"></i> Libros</a>
        <a href="<?= htmlspecialchars($basePath) ?>usuarios/index.php" <?= strpos($rutaNormalizada, 'usuarios') !== false ? 'class="active"' : '' ?>><i class="fas fa-users"></i> Usuarios</a>
        <a href="<?= htmlspecialchars($basePath) ?>prestamos/index.php" <?= strpos($rutaNormalizada, 'prestamos') !== false ? 'class="active"' : '' ?>><i class="fas fa-hand-holding-heart"></i> Préstamos</a>
    </nav>
</aside>

<div class="main-content">
