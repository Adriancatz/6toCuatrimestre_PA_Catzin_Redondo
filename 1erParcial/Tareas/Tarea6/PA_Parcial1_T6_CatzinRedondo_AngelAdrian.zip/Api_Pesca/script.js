async function mostrarPersonaje() {
  try {
    // número aleatorio entre 1 y 826 que spn la cantidad de personajes
    const numero = Math.floor(Math.random() * 826) + 1;
    const respuesta = await fetch(`https://rickandmortyapi.com/api/character/${numero}`);
    const personaje = await respuesta.json();

    const contenedor = document.getElementById("contenedor");
    contenedor.innerHTML = ""; // limpiar antes de mostrar otro

    const tarjeta = document.createElement("div");
    tarjeta.className = "card";
    tarjeta.innerHTML = `
      <img src="${personaje.image}" alt="${personaje.name}">
      <h3>${personaje.name}</h3>
      <p><strong>Especie:</strong> ${personaje.species}</p>
      <p><strong>Estado:</strong> ${personaje.status}</p>
      <p><strong>Origen:</strong> ${personaje.origin.name}</p>
    `;
    contenedor.appendChild(tarjeta);

  } catch (error) {
    console.error("Error al cargar personaje:", error);
  }
}
