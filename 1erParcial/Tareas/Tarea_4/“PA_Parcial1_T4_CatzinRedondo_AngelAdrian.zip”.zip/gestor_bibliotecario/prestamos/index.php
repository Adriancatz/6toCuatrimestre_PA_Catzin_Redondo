<?php
// Incluye el archivo de conexión a la base de datos
require_once "../config/connection.php";

// Prepara la consulta SQL para mostrar los préstamos con JOIN a usuarios y libros
$stmt = $conn->prepare(
    "SELECT p.id, u.nombre AS nombre_usuario, MAX(l.titulo) AS titulo_libro, p.fecha_prestamo, p.fecha_devolucion " .
    "FROM prestamos p " .
    "JOIN usuarios u ON p.id_usuario = u.id " .              // Relación préstamo → usuario
    "JOIN detalle_prestamo dp ON dp.id_prestamo = p.id " .   // Relación préstamo → detalle
    "JOIN libros l ON dp.id_libro = l.id " .                 // Relación detalle → libro
    "GROUP BY p.id, u.nombre, p.fecha_prestamo, p.fecha_devolucion" // Agrupa por préstamo
);

// Ejecuta la consulta
$stmt->execute();

// Obtiene el resultado de la consulta
$result = $stmt->get_result();

// Convierte todos los registros en un array asociativo
$prestamos = $result->fetch_all(MYSQLI_ASSOC);

// Cierra el statement y la conexión
$stmt->close();
$conn->close();
?>
<?php include_once "../includes/header.php";  ?> <!-- Incluye el encabezado común -->

<div class="page-header">
    <h1><i class="fas fa-hand-holding-heart"></i> Préstamos</h1> <!-- Título con ícono -->
    <a href="create.php" class="btn btn-primary">
        <i class="fas fa-plus"></i> Nuevo Préstamo <!-- Botón para crear nuevo préstamo -->
    </a>
</div>

<div class="card">
    <div class="card-body">
        <!-- Tabla para mostrar la lista de préstamos -->
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th> <!-- Columna ID -->
                    <th>Usuario</th> <!-- Columna Usuario -->
                    <th>Libro</th> <!-- Columna Libro -->
                    <th>Fecha de Préstamo</th> <!-- Columna Fecha de préstamo -->
                    <th>Fecha de Devolución</th> <!-- Columna Fecha de devolución -->
                    <th>Acciones</th> <!-- Columna Acciones -->
                </tr>
            </thead>
            <tbody>
                <!-- Recorre todos los préstamos obtenidos -->
                <?php foreach ($prestamos as $prestamo): ?>
                    <tr>
                        <!-- Muestra los datos del préstamo -->
                        <td><?= $prestamo['id'] ?></td>
                        <td><?= htmlspecialchars($prestamo['nombre_usuario']) ?></td>
                        <td><?= htmlspecialchars($prestamo['titulo_libro']) ?></td>
                        <td><?= htmlspecialchars($prestamo['fecha_prestamo']) ?></td>
                        <td><?= htmlspecialchars($prestamo['fecha_devolucion']) ?></td>
                        <td>
                            <!-- Botón para editar el préstamo -->
                            <a href="edit.php?id=<?= $prestamo['id'] ?>" class="btn btn-sm btn-warning">
                                <i class="fas fa-edit"></i> Editar
                            </a>
                            <!-- Botón para eliminar el préstamo con confirmación -->
                            <a href="delete.php?id=<?= $prestamo['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('¿Estás seguro de eliminar este préstamo?');">
                                <i class="fas fa-trash"></i> Eliminar
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include_once "../includes/footer.php";  ?> <!-- Incluye el pie de página común -->
