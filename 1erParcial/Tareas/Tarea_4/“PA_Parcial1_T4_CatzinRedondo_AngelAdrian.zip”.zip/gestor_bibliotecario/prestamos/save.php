<?php
// Incluye el archivo de conexión a la base de datos
require_once "../config/connection.php";

// Verifica que la solicitud se haya hecho por método POST
// Esto asegura que el formulario fue enviado correctamente
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtiene y valida los datos enviados desde el formulario
    $id_usuario = intval($_POST['id_usuario'] ?? 0);
    $id_libro = intval($_POST['id_libro'] ?? 0);
    $fecha_prestamo = $_POST['fecha_prestamo'] ?? '';
    $fecha_devolucion = $_POST['fecha_devolucion'] ?? '';

    // Valida que todos los campos obligatorios estén completos
    if ($id_usuario <= 0 || $id_libro <= 0 || $fecha_prestamo === '' || $fecha_devolucion === '') {
        header("Location: create.php?error=Todos los campos son obligatorios.");
        exit();
    }

    // Prepara la consulta SQL para insertar un nuevo préstamo
    // En este caso, se guarda directamente el usuario, libro y fechas
    $stmt = $conn->prepare("INSERT INTO prestamos (id_usuario, id_libro, fecha_prestamo, fecha_devolucion) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("iiss", $id_usuario, $id_libro, $fecha_prestamo, $fecha_devolucion);

    // Ejecuta la consulta
    if ($stmt->execute()) {
        // Si la inserción fue exitosa, redirige con mensaje de éxito
        header("Location: index.php?success=Préstamo creado correctamente.");
        exit();
    } else {
        // Si hubo error en la inserción, redirige con mensaje de error
        header("Location: create.php?error=Error al crear el préstamo.");
        exit();
    }

    // Cierra el statement y la conexión
    $stmt->close();
    $conn->close();
} else {
    // Si la solicitud no fue por POST, redirige con mensaje de error
    header("Location: index.php?error=Solicitud no válida.");
    exit();
}
?>
