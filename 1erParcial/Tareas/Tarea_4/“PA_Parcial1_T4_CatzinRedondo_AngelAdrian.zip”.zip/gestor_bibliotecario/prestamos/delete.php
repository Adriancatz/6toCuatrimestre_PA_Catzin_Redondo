<?php
// Incluye el archivo de conexión a la base de datos
require_once "../config/connection.php";

// Verifica si se recibió el parámetro 'id' por la URL
// Este ID corresponde al préstamo que se desea eliminar
if (isset($_GET['id'])) {
    // Convierte el valor recibido a entero para mayor seguridad
    $id = intval($_GET['id']);
    
    // Prepara la consulta SQL para eliminar un préstamo por su ID
    $stmt = $conn->prepare("DELETE FROM prestamos WHERE id = ?");
    
    // Vincula el parámetro ID a la consulta (tipo entero "i")
    $stmt->bind_param("i", $id);
    
    // Ejecuta la consulta
    if ($stmt->execute()) {
        // Si la eliminación fue exitosa, redirige con mensaje de éxito
        header("Location: index.php?success=Préstamo eliminado correctamente.");
        exit();
    } else {
        // Si hubo error en la eliminación, redirige con mensaje de error
        header("Location: index.php?error=Error al eliminar el préstamo.");
        exit();
    }

    // Cierra el statement y la conexión
    $stmt->close();
    $conn->close();
} else {
    // Si no se especificó un ID en la URL, redirige con mensaje de error
    header("Location: index.php?error=ID de préstamo no especificado.");
    exit();
}
?>
