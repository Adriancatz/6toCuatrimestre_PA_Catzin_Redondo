<?php
// Incluye el archivo de conexión a la base de datos
require_once "../config/connection.php";

// Obtiene el ID del préstamo desde la URL y lo valida
$id = intval($_GET['id'] ?? 0);
if ($id <= 0) {
    // Si no se especificó un ID válido, redirige con mensaje de error
    header("Location: index.php?error=ID de préstamo no especificado.");
    exit();
}

// Prepara la consulta SQL para obtener los datos del préstamo
$stmt = $conn->prepare(
    "SELECT p.id_usuario, dp.id_libro, p.fecha_prestamo, p.fecha_devolucion " .
    "FROM prestamos p " .
    "LEFT JOIN detalle_prestamo dp ON dp.id_prestamo = p.id " . // Relación préstamo → detalle
    "WHERE p.id = ?"                                            // Filtra por ID del préstamo
);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

// Si se encontró el préstamo, guarda sus datos en variables
if ($result && $result->num_rows > 0) {
    $prestamo = $result->fetch_assoc();
    $id_usuario = intval($prestamo['id_usuario']);
    $id_libro = intval($prestamo['id_libro']);
    $fecha_prestamo = $prestamo['fecha_prestamo'];
    $fecha_devolucion = $prestamo['fecha_devolucion'];
} else {
    // Si no se encontró el préstamo, redirige con mensaje de error
    $stmt->close();
    $conn->close();
    header("Location: index.php?error=Préstamo no encontrado.");
    exit();
}
$stmt->close();

// Consulta todos los usuarios para llenar el <select>
$stmtUsuarios = $conn->prepare("SELECT id, nombre, apellido FROM usuarios ORDER BY nombre");
$stmtUsuarios->execute();
$resultUsuarios = $stmtUsuarios->get_result();
$stmtUsuarios->close();

// Consulta todos los libros para llenar el <select>
$stmtLibros = $conn->prepare("SELECT id, titulo FROM libros ORDER BY titulo");
$stmtLibros->execute();
$resultLibros = $stmtLibros->get_result();
$stmtLibros->close();

// Cierra la conexión
$conn->close();
?>
<?php include_once "../includes/header.php"; ?> <!-- Incluye el encabezado común -->

<div class="page-header">
    <h1><i class="fas fa-edit"></i> Editar Préstamo</h1> <!-- Título con ícono -->
    <a href="index.php" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i> Volver <!-- Botón para regresar -->
    </a>
</div>

<!-- Muestra mensaje de error si existe en la URL -->
<?php if (isset($_GET['error'])): ?>
    <div class="alert alert-danger">
        <?= htmlspecialchars($_GET['error']) ?>
    </div>
<?php endif; ?>

<div class="card">
    <!-- Formulario para editar un préstamo existente -->
    <form action="update.php" method="POST">
        <!-- Campo oculto para enviar el ID del préstamo -->
        <input type="hidden" name="id" value="<?= $id ?>">

        <div class="form-group">
            <label>Usuario</label>
            <select name="id_usuario" required>
                <option value="">Seleccione un usuario</option>
                <!-- Lista dinámica de usuarios con selección del actual -->
                <?php while ($usuario = $resultUsuarios->fetch_assoc()): ?>
                    <option value="<?= $usuario['id'] ?>" <?= $usuario['id'] == $id_usuario ? 'selected' : '' ?>>
                        <?= htmlspecialchars($usuario['nombre'] . ' ' . $usuario['apellido']) ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>

        <div class="form-group">
            <label>Libro</label>
            <select name="id_libro" required>
                <option value="">Seleccione un libro</option>
                <!-- Lista dinámica de libros con selección del actual -->
                <?php while ($libro = $resultLibros->fetch_assoc()): ?>
                    <option value="<?= $libro['id'] ?>" <?= $libro['id'] == $id_libro ? 'selected' : '' ?>>
                        <?= htmlspecialchars($libro['titulo']) ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>

        <div class="form-group">
            <label>Fecha de Préstamo</label>
            <!-- Campo de fecha con valor actual -->
            <input type="date" name="fecha_prestamo" value="<?= htmlspecialchars($fecha_prestamo) ?>" required>
        </div>

        <div class="form-group">
            <label>Fecha de Devolución</label>
            <!-- Campo de fecha con valor actual -->
            <input type="date" name="fecha_devolucion" value="<?= htmlspecialchars($fecha_devolucion) ?>" required>
        </div>

        <!-- Botón para enviar el formulario -->
        <button type="submit" class="btn btn-primary">Actualizar Préstamo</button>
    </form>
</div>

<?php include_once "../includes/footer.php"; ?> <!-- Incluye el pie de página común -->
