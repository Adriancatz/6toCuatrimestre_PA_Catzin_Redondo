<?php
// Incluye el archivo de conexión a la base de datos
require_once "../config/connection.php";

// Verifica que la solicitud se haya hecho por método POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtiene y valida los datos enviados desde el formulario
    $id = intval($_POST['id'] ?? 0);
    $id_usuario = intval($_POST['id_usuario'] ?? 0);
    $id_libro = intval($_POST['id_libro'] ?? 0);
    $fecha_prestamo = $_POST['fecha_prestamo'] ?? '';
    $fecha_devolucion = $_POST['fecha_devolucion'] ?? '';

    // Valida que todos los campos obligatorios estén completos
    if ($id <= 0 || $id_usuario <= 0 || $id_libro <= 0 || $fecha_prestamo === '' || $fecha_devolucion === '') {
        header("Location: edit.php?id={$id}&error=Todos los campos son obligatorios.");
        exit();
    }

    // Actualiza los datos principales del préstamo
    $stmt = $conn->prepare("UPDATE prestamos SET id_usuario = ?, fecha_prestamo = ?, fecha_devolucion = ? WHERE id = ?");
    $stmt->bind_param("issi", $id_usuario, $fecha_prestamo, $fecha_devolucion, $id);

    // Si falla la actualización, redirige con mensaje de error
    if (!$stmt->execute()) {
        $stmt->close();
        $conn->close();
        header("Location: edit.php?id={$id}&error=Error al actualizar el préstamo.");
        exit();
    }
    $stmt->close();

    // Verifica si ya existe un detalle de préstamo asociado
    $stmtExiste = $conn->prepare("SELECT COUNT(*) FROM detalle_prestamo WHERE id_prestamo = ?");
    $stmtExiste->bind_param("i", $id);
    $stmtExiste->execute();
    $stmtExiste->bind_result($detalleCount);
    $stmtExiste->fetch();
    $stmtExiste->close();

    // Si existe detalle, lo actualiza con el nuevo libro
    if ($detalleCount > 0) {
        $stmtDetalle = $conn->prepare("UPDATE detalle_prestamo SET id_libro = ? WHERE id_prestamo = ?");
        $stmtDetalle->bind_param("ii", $id_libro, $id);
        $stmtDetalle->execute();
        $stmtDetalle->close();
    } else {
        // Si no existe detalle, lo inserta con cantidad = 1
        $stmtInsertDetalle = $conn->prepare("INSERT INTO detalle_prestamo (id_prestamo, id_libro, cantidad) VALUES (?, ?, 1)");
        $stmtInsertDetalle->bind_param("ii", $id, $id_libro);
        $stmtInsertDetalle->execute();
        $stmtInsertDetalle->close();
    }

    // Cierra la conexión y redirige con mensaje de éxito
    $conn->close();
    header("Location: index.php?success=Préstamo actualizado correctamente.");
    exit();
} else {
    // Si la solicitud no fue por POST, redirige con mensaje de error
    header("Location: index.php?error=Solicitud no válida.");
    exit();
}
?>
