<?php
require_once "../config/connection.php";

$rolesStmt = $conn->prepare("SELECT id, nombre FROM roles ORDER BY nombre");
$rolesStmt->execute();
$rolesResult = $rolesStmt->get_result();
$rolesStmt->close();
?>
<?php include_once "../includes/header.php"; ?>
<div class="page-header">
    <h1><i class="fas fa-user-plus"></i> Nuevo Usuario</h1>
    <a href="index.php" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i> Volver
    </a>
</div>
<div class="card">
    <form action="save.php" method="POST">
        <div class="form-group">
            <label><i class="fas fa-user"></i> Nombre</label>
            <input type="text" name="nombre" placeholder="Ej: Angel" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-user"></i> Apellido</label>
            <input type="text" name="apellido" placeholder="Ej: Ochoa" required>    
        </div>
        <div class="form-group">
            <label><i class="fas fa-envelope"></i> Correo</label>
            <input type="email" name="correo" placeholder="Ej: Angel8a@ejemplo.com" required>
        </div>
        <div class="form-group">
            <label><i class="fas fa-user-shield"></i> Rol</label>
            <select name="id_rol" required>
                <option value="">Seleccione un rol</option>
                <?php while ($rol = $rolesResult->fetch_assoc()): ?>
                    <option value="<?= $rol['id'] ?>"><?= htmlspecialchars($rol['nombre']) ?></option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="form-group">
            <label><i class="fas fa-lock"></i> Contraseña</label>
            <input type="password" name="password" placeholder="Ej: contraseña required>
        </div>
        <button type="submit" class="btn btn-primary">
            <i class="fas fa-save"></i> Guardar Usuario
        </button>
    </form>
</div>
<?php include_once "../includes/footer.php";  ?>


