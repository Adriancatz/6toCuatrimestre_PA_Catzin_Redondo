<?php 
// Incluye el archivo de conexión a la base de datos
require_once "../config/connection.php";

// Prepara la consulta SQL para obtener todos los usuarios
$stmt = $conn->prepare("SELECT * FROM usuarios");

// Ejecuta la consulta
$stmt->execute();

// Obtiene el resultado de la consulta
$result = $stmt->get_result();

// Convierte todos los registros en un array asociativo
$usuarios = $result->fetch_all(MYSQLI_ASSOC);

// Cierra el statement
$stmt->close();
?>
<?php include_once "../includes/header.php";  ?> <!-- Incluye el encabezado común de la página -->

<div class="page-header">
    <h1><i class="fas fa-users"></i> Usuarios</h1> <!-- Título con ícono -->
    <a href="create.php" class="btn btn-primary">
        <i class="fas fa-user-plus"></i> Nuevo Usuario <!-- Botón para crear nuevo usuario -->
    </a>
</div>

<div class="card">
    <!-- Tabla para mostrar la lista de usuarios -->
    <table class="table table-striped">
        <thead>
            <tr>
                <th>ID</th> <!-- Columna ID -->
                <th>Nombre</th> <!-- Columna Nombre -->
                <th>Apellido</th> <!-- Columna Apellido -->
                <th>Email</th> <!-- Columna Correo -->
                <th>Acciones</th> <!-- Columna Acciones -->
            </tr>
        </thead>
        <tbody>
            <!-- Recorre todos los usuarios obtenidos de la base de datos -->
            <?php foreach ($usuarios as $usuario): ?>
                <tr>
                    <!-- Muestra los datos del usuario -->
                    <td><?= $usuario['id'] ?></td>
                    <td><?= htmlspecialchars($usuario['nombre']) ?></td>
                    <td><?= htmlspecialchars($usuario['apellido']) ?></td>
                    <td><?= htmlspecialchars($usuario['correo']) ?></td>
                    <td>
                        <!-- Botón para editar el usuario -->
                        <a href="edit.php?id=<?= $usuario['id'] ?>" class="btn btn-sm btn-warning">
                            <i class="fas fa-edit"></i> Editar
                        </a>
                        <!-- Botón para eliminar el usuario con confirmación -->
                        <a href="delete.php?id=<?= $usuario['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('¿Estás seguro de eliminar este usuario?');">
                            <i class="fas fa-trash"></i> Eliminar
                        </a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php include_once "../includes/footer.php";  ?> <!-- Incluye el pie de página común -->
