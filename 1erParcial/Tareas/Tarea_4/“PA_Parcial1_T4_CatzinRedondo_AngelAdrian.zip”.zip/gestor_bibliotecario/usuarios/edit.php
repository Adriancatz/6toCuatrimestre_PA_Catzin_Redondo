<?php 
// Incluye el archivo de conexión a la base de datos
require_once "../config/connection.php";

// Verifica si se recibió el parámetro 'id' por la URL
if (isset($_GET['id'])) {
    // Convierte el valor recibido a entero para mayor seguridad
    $id = intval($_GET['id']);
    
    // Prepara la consulta SQL para obtener los datos del usuario con ese ID
    $stmt = $conn->prepare("SELECT * FROM usuarios WHERE id = ?");
    
    // Vincula el parámetro ID a la consulta (tipo entero "i")
    $stmt->bind_param("i", $id);
    
    // Ejecuta la consulta
    $stmt->execute();
    
    // Obtiene el resultado de la consulta
    $result = $stmt->get_result();
    
    // Extrae los datos del usuario en un array asociativo
    $usuario = $result->fetch_assoc();
    
    // Cierra el statement
    $stmt->close();
} else {
    // Si no se especificó un ID en la URL, redirige con mensaje de error
    header("Location: index.php?error=ID de usuario no especificado.");
    exit();
}
?>
<?php include_once "../includes/header.php";  ?> <!-- Incluye el encabezado común de la página -->

<div class="page-header">
    <h1><i class="fas fa-user-edit"></i> Editar Usuario</h1> <!-- Título con ícono -->
    <a href="index.php" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i> Volver <!-- Botón para regresar al listado -->
    </a>
</div>

<div class="card">
    <!-- Formulario para editar un usuario existente -->
    <form action="update.php" method="POST">
        <!-- Campo oculto para enviar el ID del usuario -->
        <input type="hidden" name="id" value="<?= $usuario['id'] ?>">

        <div class="form-group">
            <label><i class="fas fa-user"></i> Nombre</label>
            <!-- Campo de texto con el nombre actual del usuario -->
            <input type="text" name="nombre" value="<?= htmlspecialchars($usuario['nombre']) ?>" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-user"></i> Apellido</label>
            <!-- Campo de texto con el apellido actual del usuario -->
            <input type="text" name="apellido" value="<?= htmlspecialchars($usuario['apellido']) ?>" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-envelope"></i> Correo</label>
            <!-- Campo de texto con el correo actual del usuario -->
            <input type="email" name="correo" value="<?= htmlspecialchars($usuario['correo']) ?>" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-lock"></i> Contraseña</label>
            <!-- Campo de contraseña, si se deja vacío mantiene la actual -->
            <input type="password" name="password" placeholder="Deja en blanco si no quieres editar tu contraseña">
        </div>

        <!-- Botón para enviar el formulario -->
        <button type="submit" class="btn btn-primary">
            <i class="fas fa-save"></i> Guardar Cambios
        </button>
    </form>
</div>

<?php include_once "../includes/footer.php";  ?> <!-- Incluye el pie de página común -->
