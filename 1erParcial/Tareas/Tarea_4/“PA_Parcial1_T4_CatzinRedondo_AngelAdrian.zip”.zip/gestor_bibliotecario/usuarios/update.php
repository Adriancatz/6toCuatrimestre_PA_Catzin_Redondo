<?php
// Incluye el archivo de conexión a la base de datos
require_once "../config/connection.php";

// Verifica que la solicitud se haya hecho por método POST
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: index.php?error=Solicitud no válida.");
    exit();
}

// Obtiene y valida los datos enviados desde el formulario
$id = intval($_POST['id'] ?? 0);
$nombre = trim($_POST['nombre'] ?? '');
$apellido = trim($_POST['apellido'] ?? '');
$correo = trim($_POST['correo'] ?? '');
$password = $_POST['password'] ?? '';

// Si faltan datos obligatorios, redirige con error
if ($id <= 0 || $nombre === '' || $apellido === '' || $correo === '') {
    header("Location: index.php?error=Datos incompletos.");
    exit();
}

// Verifica que el correo no esté en uso por otro usuario distinto al actual
$stmt = $conn->prepare("SELECT id FROM usuarios WHERE correo = ? AND id <> ?");
$stmt->bind_param("si", $correo, $id);
$stmt->execute();
$result = $stmt->get_result();
if ($result && $result->num_rows > 0) {
    $stmt->close();
    $conn->close();
    header("Location: edit.php?id={$id}&error=El correo ya está en uso por otro usuario.");
    exit();
}
$stmt->close();

// Si el usuario ingresó una nueva contraseña, la actualiza
if ($password !== '') {
    $password_hash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("UPDATE usuarios SET nombre = ?, apellido = ?, correo = ?, password = ? WHERE id = ?");
    $stmt->bind_param("ssssi", $nombre, $apellido, $correo, $password_hash, $id);
} else {
    // Si no ingresó contraseña, se conserva la actual
    $stmt = $conn->prepare("UPDATE usuarios SET nombre = ?, apellido = ?, correo = ? WHERE id = ?");
    $stmt->bind_param("sssi", $nombre, $apellido, $correo, $id);
}

// Ejecuta la actualización
if ($stmt->execute()) {
    // Si fue exitosa, cierra conexiones y redirige con mensaje de éxito
    $stmt->close();
    $conn->close();
    header("Location: index.php?success=Usuario actualizado correctamente.");
    exit();
} else {
    // Si hubo error, cierra conexiones y redirige con mensaje de error
    $error = urlencode("Error al actualizar el usuario.");
    $stmt->close();
    $conn->close();
    header("Location: edit.php?id={$id}&error={$error}");
    exit();
}
?>
