<?php
// Incluye el archivo de conexión a la base de datos
require_once "../config/connection.php";

// Verifica que la solicitud se haya hecho por método POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtiene y limpia los valores enviados desde el formulario
    $nombre = trim($_POST['nombre'] ?? '');
    $apellido = trim($_POST['apellido'] ?? '');
    $correo = trim($_POST['correo'] ?? '');
    $password = $_POST['password'] ?? '';
    $rol_id = intval($_POST['rol_id'] ?? 0);

    // Valida que todos los campos obligatorios estén completos
    if ($nombre === '' || $apellido === '' || $correo === '' || $password === '' || $rol_id <= 0) {
        header("Location: create.php?error=Todos los campos son obligatorios.");
        exit();
    }

    // Genera un hash seguro de la contraseña
    $passwordHash = password_hash($password, PASSWORD_DEFAULT);

    // Prepara la consulta SQL para insertar un nuevo usuario
    $stmt = $conn->prepare("INSERT INTO usuarios (nombre, apellido, correo, password, id_rol) VALUES (?, ?, ?, ?, ?)");

    // Vincula los parámetros a la consulta (ssssi = string, string, string, string, integer)
    $stmt->bind_param("ssssi", $nombre, $apellido, $correo, $passwordHash, $rol_id);

    // Ejecuta la consulta
    if ($stmt->execute()) {
        // Si la inserción fue exitosa, cierra conexiones y redirige con mensaje de éxito
        $stmt->close();
        $conn->close();
        header("Location: index.php?success=Usuario creado correctamente.");
        exit();
    } else {
        // Si hubo error en la inserción, cierra conexiones y redirige con mensaje de error
        $stmt->close();
        $conn->close();
        header("Location: create.php?error=Error al crear el usuario.");
        exit();
    }
} else {
    // Si la solicitud no fue por POST, redirige con mensaje de error
    header("Location: index.php?error=Solicitud no válida.");
    exit();
}
?>
