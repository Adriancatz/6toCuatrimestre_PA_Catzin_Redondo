// Función que pide un perro aleatorio a la API
function fetchDog() {
  fetch("https://dog.ceo/api/breeds/image/random")
    .then(res => res.json())
    .then(data => {

      // Imagen
      const img = document.getElementById("imagen-de-perro");
      img.src = data.message;

      // Obtener raza desde la URL
      const partesurl = data.message.split("/");
      const nombre = partesurl[4].replace("-", " ");

      // Texto de la raza
      const nombreText = document.getElementById("raza");
      nombreText.textContent = "Raza de perro: " + nombre;
    })
    .catch(err => console.error("Error:", err));
}

// Cargar un perro al inicio
fetchDog();

// Botón para pedir otro perro
document.getElementById("new-dog").addEventListener("click", fetchDog);
